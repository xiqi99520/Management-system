<template>
  <div>manager-detail</div>
</template>
