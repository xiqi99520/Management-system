<template>
  <router-view></router-view>
</template>
<script>
export default {
  name: 'incomingData'
}
</script>
<style lang="less">
@import "~@/style/color";
</style>
