<template>
  <router-view></router-view>
</template>
<script>
export default {
  name: 'postLanManagement'
}
</script>
<style lang="less">
@import "~@/style/color";
</style>
