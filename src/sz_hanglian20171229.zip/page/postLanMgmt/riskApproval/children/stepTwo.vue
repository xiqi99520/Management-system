<template>
    <el-container>
      <el-main class="view-container">
         <table class="table-view">
          <tbody>
            <tr>
              <th>申请编号</th>
              <td>FC0001</td>
              <th>姓名</th>
              <td>张三</td>
              <th>贷款额</th>
              <td>1600万元</td>
              <th>房产估值</th>
              <td>1400-1600万元</td>
            </tr>
            <tr>
              <th>申请时间</th>
              <td>2017/10/13 18:00</td>
              <th>抵押情况</th>
              <td>一抵</td>
              <th>贷款期限</th>
              <td>24个月</td>
              <th>房产地址</th>
              <td>朝阳区-燕莎-远洋新干线</td>
            </tr>
          </tbody>
        </table>
        <div class="view-box">
          <div class="view-box-title">
            <i class="iconfont icon-dianzhui"></i> 贷款人信息
          </div>
          <div class="view-box-body">
            <table class="table-view">
              <tbody>
                <tr>
                  <th width="120px">贷款人姓名</th>
                  <td>张无忌</td>
                  <th width="120px">贷款人身份证号</th>
                  <td>10014454545</td>
                  <th width="120px">婚姻状况</th>
                  <td>已婚</td>
                </tr>
                <tr>
                  <th width="120px">是否有工作单位</th>
                  <td>是</td>
                  <th width="120px">工作单位</th>
                  <td>森木集团</td>
                  <th width="120px">职务</th>
                  <td>项目总监</td>
                </tr>
              </tbody>
            </table>
            <table class="table-view">
              <tbody>
                <tr>
                  <th width="120px">配偶姓名</th>
                  <td>赵明</td>
                  <th width="120px">配偶身份证号</th>
                  <td>10014454545</td>
                  <th width="120px">&nbsp;</th>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <th width="120px">是否有工作单位</th>
                  <td>是</td>
                  <th width="120px">工作单位</th>
                  <td>神木集团</td>
                  <th width="120px">职务</th>
                  <td>财务总监</td>
                </tr>
              </tbody>
            </table>
            <table class="table-view">
              <tbody>
                <tr>
                  <th width="120px">产权人姓名</th>
                  <td>张无忌，赵明</td>
                  <th width="120px">贷款人占有比例</th>
                  <td> 50%</td>
                  <th width="120px">&nbsp;</th>
                  <td>&nbsp;</td>
                </tr>
              </tbody>
            </table>
            <table class="table-view">
              <tbody>
                <tr>
                  <th width="130px">是否有实际用款人</th>
                  <td>是</td>
                  <th width="130px">实际用款人姓名</th>
                  <td>赵明</td>
                  <th width="130px">实际用款人身份证号</th>
                  <td>15615512151212</td>
                </tr>
                <tr>
                  <th width="130px">是否有工作单位</th>
                  <td>是</td>
                  <th width="130px">工作单位</th>
                  <td>神木集团</td>
                  <th width="130px">职务</th>
                  <td>财务总监</td>
                </tr>
              </tbody>
            </table>
            <table class="table-view">
              <tbody>
                <tr>
                  <th width="130px">是否有其他共贷人</th>
                  <td>是</td>
                  <th width="130px">实际用款人姓名</th>
                  <td>张三分</td>
                  <th width="130px">实际用款人身份证号</th>
                  <td>1421342423423</td>
                </tr>
                <tr>
                  <th width="130px">是否有工作单位</th>
                  <td>是</td>
                  <th width="130px">工作单位</th>
                  <td>大幕集团</td>
                  <th width="130px">职务</th>
                  <td>总经理</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div class="view-box">
          <div class="view-box-title">
            <i class="iconfont icon-dianzhui"></i> 抵押物信息
          </div>
          <div class="view-box-body">
            <table class="table-view">
              <tbody>
                <tr>
                  <th width="120px">房产证号</th>
                  <td>京CNP6515156515</td>
                  <th width="120px">房屋地址</th>
                  <td>北京市朝阳区霞光里66号院</td>
                  <th width="120px">规划用途</th>
                  <td>住宅</td>
                </tr>
                <tr>
                  <th width="120px">建筑面积</th>
                  <td>95㎡</td>
                  <th width="120px">地下面积</th>
                  <td>0㎡</td>
                  <th width="120px">房屋类型</th>
                  <td>三居室</td>
                </tr>
              </tbody>
            </table>
            <table class="table-view">
              <tbody>
                <tr>
                  <th width="120px">小区名称</th>
                  <td>远洋新干线</td>
                  <th width="120px">房屋位置</th>
                  <td>朝阳区霞光里66号远翔新干线8栋602</td>
                  <th width="120px">房屋户型</th>
                  <td>3室1厅1厨1卫</td>
                </tr>
                <tr>
                  <th width="120px">房屋朝向</th>
                  <td>正南</td>
                  <th width="120px">所在楼层</th>
                  <td>6</td>
                  <th width="120px">总楼层</th>
                  <td>28</td>
                </tr>
              </tbody>
            </table>
            <table class="table-view">
              <tbody>
                <tr>
                  <th width="120px">产权获取方式</th>
                  <td>购买</td>
                  <th width="120px">产权年数</th>
                  <td>70年</td>
                  <th width="120px">满五唯一</th>
                  <td>是</td>
                </tr>
                <tr>
                  <th width="120px">学区房</th>
                  <td>是</td>
                  <th width="120px">学区学校</th>
                  <td>北京化工大学附属中学</td>
                  <th width="120px">&nbsp;</th>
                  <td>&nbsp;</td>
                </tr>
              </tbody>
            </table>
            <table class="table-view">
              <tbody>
                <tr>
                  <th width="120px">房产性质</th>
                  <td>商品房</td>
                  <th width="120px">抵押类型</th>
                  <td>二抵</td>
                  <th width="120px">房屋实际用途</th>
                  <td>自住</td>
                </tr>
                <tr>
                  <th width="120px">建成年份</th>
                  <td>2011</td>
                  <th width="120px">车位情况</th>
                  <td>有车位</td>
                  <th width="120px">家庭成员</th>
                  <td>夫妻，小孩</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <!--表单-->
        <el-row type="flex" class="row-bg" justify="space-between">
          <el-col align="left">
            <el-form-item label="周边环境" class="form-item">
                <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 6}" v-model="reviewForm.surroundingEnv" placeholder="该小区周边配套齐全....." style="width:100%"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row type="flex" class="row-bg">
          <el-col :span="24" align="left">
            <el-form-item label="小区环境" class="form-item">
                <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 6}" v-model="reviewForm.plotEnv" placeholder="该小区周边配套齐全....." style="width:100%"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row type="flex" class="row-bg">
          <el-col :span="24" align="left">
            <el-form-item label="整栋楼体状况" class="form-item">
                <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 6}" v-model="reviewForm.theBuildingStatus" placeholder="该楼为钢混结构....." style="width:100%"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row type="flex" class="row-bg">
          <el-col :span="24" align="left">
            <el-form-item label="室内状况" class="form-item">
                <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 6}" v-model="reviewForm.roomStatus" placeholder="该房为精装3居室....." style="width:100%"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row type="flex" class="row-bg">
          <el-col :span="24" align="left">
            <el-form-item label="居住状况" class="form-item">
                <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 6}" v-model="reviewForm.residenceStatus" placeholder="该房由购房人家人居住....." style="width:100%"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <table class="table-view">
          <tbody>
            <tr>
              <th width="100px">中介公司1</th>
              <td>链家地产</td>
              <th width="100px">市场价1</th>
              <td>1500万元</td>
              <th width="100px">快出价1</th>
              <td>1498万元</td>
            </tr>
            <tr>
              <th width="100px">中介公司2</th>
              <td>我爱我家</td>
              <th width="100px">市场价2</th>
              <td>1488万元</td>
              <th width="100px">快出价2</th>
              <td>1488万元</td>
            </tr>
          </tbody>
        </table>
        <el-row type="flex" class="row-bg">
          <el-col :span="24" align="left">
            <el-form-item label="询价综合概述" class="form-item">
                <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 6}" v-model="reviewForm.priceSummary" placeholder="该小区平均挂牌价格为10-12万元不等，根据面积和楼层及装修询得....." style="width:100%"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <!--借款人影像资料-->
        <div class="view-box">
          <div class="view-box-title">
            <i class="iconfont icon-dianzhui"></i> 贷款人影像资料
          </div>
          <div class="view-box-body">
            <table class="table-view">
              <tbody>
                <tr>
                  <th class="img-type">
                    身份证
                    <p>（借款人、借款人配偶、产权人、共借人）</p>
                  </th>
                  <td>
                    <el-row type="flex">
                      <el-col :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                      <el-col :offset="3" :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                    </el-row>
                  </td>
                </tr>
                <tr>
                  <th class="img-type">
                    户口本
                    <p>（产权人、产权人配偶）</p>
                  </th>
                  <td>
                    <el-row type="flex">
                      <el-col :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                      <el-col :offset="3" :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                    </el-row>
                  </td>
                </tr>
                <tr>
                  <th class="img-type">
                    婚姻证件
                    <p>（产权人、产权人配偶）</p>
                  </th>
                  <td>
                    <el-row type="flex">
                      <el-col :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                      <el-col :offset="3" :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                    </el-row>
                  </td>
                </tr>
                <tr>
                  <th class="img-type">征信报告</th>
                  <td>
                    <el-row type="flex">
                      <el-col :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                      <el-col :offset="3" :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                    </el-row>
                  </td>
                </tr>
                <tr>
                  <th class="img-type">
                    备用房房本
                    <p>（可选）</p>
                  </th>
                  <td>
                    <el-row type="flex">
                      <el-col :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                      <el-col :offset="3" :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                    </el-row>
                  </td>
                </tr>
                <tr>
                  <th class="img-type">
                    遗产继承公证&放弃继承公证
                    <p>（可选）</p>
                  </th>
                  <td>
                    <el-row type="flex">
                      <el-col :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                      <el-col :offset="3" :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                    </el-row>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <!--抵押物影像资料-->
        <div class="view-box">
          <div class="view-box-title">
            <i class="iconfont icon-dianzhui"></i> 抵押物影像资料
          </div>
          <div class="view-box-body">
            <table class="table-view">
              <tbody>
                <tr>
                  <th class="img-type">合同与房本</th>
                  <td>
                    <el-row type="flex">
                      <el-col :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                      <el-col :offset="3" :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                    </el-row>
                  </td>
                </tr>
                <tr>
                  <th class="img-type">
                    出租情况<br>
                    抵押房屋是否出租：是<br>
                    租赁合同甲方是否为抵押物所有人：否
                  </th>
                  <td>
                    <el-row type="flex">
                      <el-col :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                      <el-col :offset="3" :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                    </el-row>
                  </td>
                </tr>
                <tr>
                  <th class="img-type">
                    户外影像
                    <p>（小区大门，小区环境，楼栋外观，楼牌号，单元号，门牌号）</p>
                  </th>
                  <td>
                    <el-row type="flex">
                      <el-col :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                      <el-col :offset="3" :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                    </el-row>
                  </td>
                </tr>
                <tr>
                  <th class="img-type">户内影像</th>
                  <td>
                    <el-row type="flex">
                      <el-col :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                      <el-col :offset="3" :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                    </el-row>
                  </td>
                </tr>
                <tr>
                  <th class="img-type">与客户合影</th>
                  <td>
                    <el-row type="flex">
                      <el-col :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                      <el-col :offset="3" :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                    </el-row>
                  </td>
                </tr>
                <tr>
                  <th class="img-type">询价中介名片</th>
                  <td>
                    <el-row type="flex">
                      <el-col :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                      <el-col :offset="3" :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                    </el-row>
                  </td>
                </tr>
                <tr>
                  <th class="img-type">
                    一抵抵押证明<br>
                    二抵客户需提供
                  </th>
                  <td>
                    <el-row type="flex">
                      <el-col :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                      <el-col :offset="3" :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                    </el-row>
                  </td>
                </tr>
                <tr>
                  <th class="img-type">
                    公司照片
                    <p>(可选)</p>
                  </th>
                  <td>
                    <el-row type="flex">
                      <el-col :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                      <el-col :offset="3" :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                    </el-row>
                  </td>
                </tr>
                <tr>
                  <th class="img-type">
                    车辆证明
                    <p>（可选）</p>
                  </th>
                  <td>
                    <el-row type="flex">
                      <el-col :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                      <el-col :offset="3" :span="4">
                        <div class="imgInfo">
                          <img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1514476244976&di=6520831672106dd976bec21a459eec77&imgtype=0&src=http%3A%2F%2Fphotocdn.sohu.com%2F20130530%2FImg377522814.jpg">
                        </div>
                      </el-col>
                    </el-row>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </el-main>
    </el-container>
</template>
<script>
export default {
  data () {
    return {
      reviewForm: {
        surroundingEnv: '', // 周边环境
        plotEnv: '', // 小区环境
        theBuildingStatus: '', // 整栋楼体状况
        roomStatus: '', // 室内状况
        residenceStatus: '', // 居住状况
        priceSummary: '' // 询价综合概述
      }
    }
  }
}
</script>
<style lang="less" scoped>
@import "~@/style/color";
@import url('//at.alicdn.com/t/font_525204_u1yy790eizmvaemi.css');
.view-container {
  padding-top:5px;
    table {
        width: 100%;
        border-collapse: collapse;
        border: none;
        caption {
            padding: 0 5px;
            line-height: 40px;
            background-color: #96c9ff;
            text-align: left;
            color: @white
        }
        th,td {
            padding:5px 10px;
            line-height: 30px;
            border:1px solid #d1d1d1;
            text-align: left;
        }
        th {
            background-color:#e2e7ed;
            font-weight: normal;
            .title {
              color: @blue
            }
        }
        .img-type {
          width: 20%;
          text-align: center;
          p {
            font-size: 12px;
            color:#999
          }
        }
        td {
            background-color:#eef1f4;
            color: #999
        }
        .imgInfo{
            width: 200px;
            text-align: center;
            font-size: 12px;
            img {
              width: 100%;
            }
        }
    }
    .table-view {
      margin-top: 20px
    }
    .view-items {
        padding: 15px 0;
        li {
            float:left;
            width:50%;
            line-height:40px;
            text-align: left;
        }
    }
    .view-box {
      padding: 15px 0;
      .view-box-title {
        padding-top:10px;
        line-height: 30px;
        border-bottom: 1px solid #96c9ff;
        color: @blue;
        text-align: left;
        font-size: 16px
      }
    }
}
.tollyList {
  display: flex;
  .item {
    padding-right: 20px;
    line-height:30px;
    span {
      padding:3px 20px;
      background-color: #f5f7fa;
      border: 1px solid #e4e7ed;
      color: #c0c4cc;
    }
  }
}
.advanceMoney {
  padding-top: 10px;
}
</style>

