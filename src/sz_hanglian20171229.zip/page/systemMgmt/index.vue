<template>
  <router-view></router-view>
</template>
<script>
export default {
  name: 'systemManagement'
}
</script>
<style lang="less" scoped>

</style>
